Kiselgram Desktop v0.2 ALPHA (Windows)
Requires Java 21+ (https://adoptium.net)
Run: kiselgram.bat
