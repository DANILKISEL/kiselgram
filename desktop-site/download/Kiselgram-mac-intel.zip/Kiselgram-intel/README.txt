Kiselgram Desktop v0.2 ALPHA (Intel Mac)
Requires Java 21+ (https://adoptium.net)
Run: ./kiselgram.sh
